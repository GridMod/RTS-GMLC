fclose('all');                               % RTS3.m updated Nov 26, 2017
F    = zeros(90001,1,'double');              % this is the COPT LOLPs array
Fj   = zeros(1,1,'double');                  % dummy convolution variable
FD   = zeros(1,1,'double');                  % dummy convolution variable
FOR  = zeros(1,1,'single');                  % forced outage rate
DFOR = zeros(1,1,'single');                  % derated state outage rate
NVS  = zeros(1,1,'int32');                   % number of variable resources
NCG  = zeros(1,1,'int32');                   % read in gdata numb columns
NCH  = zeros(1,1,'int32');                   % read in hdata numb columns
MW   = zeros(24,'int32');                    % these will be used for flolp
SF   = zeros(20,1,'single');                 % scale factors each hour
VR   = zeros(21,1,'double');                 % DEMD & per unit hourly data
PCTC = zeros(20,1,'single');                 % VER % capacity credits
VRES = zeros(20,1,'single');                 % energy by source on NSH days
LFU1 = zeros(7,1,'single');                  % LFU1 prob of 7 step distrbtn
LFU2 = zeros(7,1,'single');                  % LFU2 PU 7 steps STD deviatin
LFU1 = [.006,.061,.242,.382,.242,.061,.006]; % the 7 probabilities of LFU
LFU2 = [0,0,0,0,0,0,0];                      % will store the +/- deviatins
DEMD = zeros(1,1,'single');                  % hourly per unit demand
LOLP24=zeros(24,1,'double');                 % saves 24 LOLPs for flolp
LOLP = zeros(1,1,'double');                  % hourly loss of load probablt
LOLE1= zeros(1,1,'double');                  % LOLE1 = sum LOLPs in the AM
LOLE2= zeros(1,1,'double');                  % LOLE2 = sum LOLPs in the PM
LOLEV= zeros(1,1,'double');                  % LOLEV = sum AM and PM LOLPs
LOLE0= zeros(1,1,'double');                  % old LOLE on previous iteratn
TLOLE= zeros(1,1,'double');                  % target LOLE to seek demand
LOLH = zeros(1,1,'double');                  % loss of load hours per year
EUE  = zeros(1,1,'double');                  % expected unserved energy/yr
ENGT = zeros(1,1,'double');                  % total demand energy/year
VRE  = zeros(1,1,'double');                  % variable resource energy/yr
VREC = zeros(1,1,'double');                  % VR energy lost or curtailed
DSF  = zeros(1,1,'double');                  % peak demand scale factor
DSFU = zeros(1,1,'double');                  % upper bound when seeking DSF
DSFL = zeros(1,1,'double');                  % lower bound when seeking DSF
D    = zeros(19,1,'double');                 % dummy numbers for average yr
HD   = zeros(1,1,'double');                  % hourly demand in MW
HD1  = zeros(1,1,'double');                  % temporary hourly MW demand
HD2  = zeros(1,1,'double');                  % temporary hourly MW demand
C2   = [3*' '];                              % dummy strings follow
D2   = C2;
C220 = [220*' '];
D220 = C220;
C14  = C220;
PLFU = 0.;                                   % percent LFU
SLOLP= 0.;                                   % significant LOLP cutoff valu
IH1  = 0;                                    % stores AM peak LOLP each day
IH2  = 0;                                    % stored PM peak LOLP each day
IH3  = 0;                                    % counts hour of the day
IOK  = 0;                                    % ok=1 print the page to flolp
JS   = 0;                                    % temporary pointer
IP   = 0;                                    % end of auto seek demand test
F1=input('GENERATOR DATA FILE NAME: ','s');  % input the name of gdata file
F2=input('TARGET LOLE (OR RETURN): ','s');   % desired LOLE or nothing
if(strcmp(F2,'') == 0)                       % see if F2 is not null
  TLOLE = sscanf(F2,'%f');                  % read the target LOLE
  IP = 0;                                    % set flag to do searching
end
if(strcmp(F2,'') == 1)                       % there is no target LOLE
  TLOLE = 0.;
  IP = 1;                                    % set flag to stop searching
end
gdata= fopen(F1);                            % this is the pointer to gdata
C220 = fgetl(gdata);                         % read NCG and title of gdata
C2   = C220(1:3);                            % copy the first 3 cols to C2
NCG  = sscanf(C2,'%d');                      % read C2 to extract the NCG
D220 = fgetl(gdata);                         % read the hdata file name
F2   = sscanf(D220(1:NCG),'%s');
fprintf(1,'%s%s\n','HOURLY DATA: ',F2);
fprintf(1,'%s\n','RTS3 is executing...');
hdata= fopen(F2);                            % this is the pointer to hdata
fout = fopen('OP.txt','wt');                 % the output report text file
fope = fopen('OP.csv','wt');                 % the output report excel file
foph = fopen('OPH.csv','wt');                % an hourly LOLP excel file
fprintf(fout,'\n%s%s',' GDATA File: ',F1);   % print gdata file name
fprintf(fope,  '%s%s',' GDATA File: ',F1);   % print gdata file name
fprintf(foph,  '%s%s',' GDATA File: ',F1);   % print gdata file name
fprintf(fout,'\n%s%s',' HDATA File: ',F2);   % print hdata file name
fprintf(fope,'\n%s%s',' HDATA File: ',F2);   % print hdata file name
fprintf(foph,'\n%s%s',' HDATA File: ',F2);   % print hdata file name
C220 = C220(4:length(C220));                 % copy the first 3 cols to C2
fprintf(fout,'\n\n %s',C220);                % print gdata title
fprintf(fope, '\n\n%s',C220);                % print gdata title
fprintf(foph, '\n\n%s',C220);                % print gdata title
C220 = fgetl(hdata);                         % read NCH and title of hdata
C2   = C220(1:3);                            % copy the first 3 cols to C2
NCH  = sscanf(C2,'%d');                      % read C2 to extract the NCH
C220 = C220(4:length(C220));                 % extract hdata title in C220
fprintf(fout,'\n %s\n',C220);                % print out hdata title
fprintf(fope,' \n%s\n',C220);                % print out hdata title
fprintf(foph,' \n%s\n',C220);                % print out hdata title
C220 = fgetl(gdata);                         % read Pk Demd LFU LOLP cutoff
[DSF PLFU SLOLP]=strread(C220(1:NCG),'%f%f%f','delimiter', ',');
C220 = fgetl(gdata);                         % read the number of VERs
NVS  = sscanf(C220(1:NCG),'%d');             % NVS= Number Variable Sources
C220 = fgetl(gdata);                         % read percents capacity credt
[PCTC]=strread(C220(1:NCG),'%f','delimiter',','); % Percent Capacty Credits
C220 = fgetl(gdata);                         % read scale factors line
[SF] = strread(C220(1:NCG),'%f','delimiter',','); % Scale Factor MW values
for i=1:7                                    % finish the STD deviation cal
  LFU2(i) = (i-4)*PLFU/100.;                 % per unit -/+ 7 deviations
end                                          % end of STD deviation
C220 = fgetl(gdata);                         % skip header for generators
% calculate the COPT, the capacity outage probability table F
fprintf(1,'%s\n','calculating the COPT');
PMAX = 0.;                                   % PMAX is the sum of gen CAPA
MXF  =  0;                                   % max MW out on the F curve
RMGEN= 0.;                                   % reserve margin MW
while ~feof(gdata)                           % while not the end of file
  C220=fgetl(gdata);                         % get the next line of gdata
% read each generators capability, reserve margin capacity % credit, forced
% outage rate, derated forced outage rate, derating MW all in the next line
[CAPA RM FOR DFOR DERA] =strread(C220(1:NCG),'%f%f%f%f%f','delimiter',',');
  RMGEN = RMGEN+CAPA*RM/100.;                % sum up the reserve margin MW
  PMAX  = PMAX+CAPA;                         % PMAX is the total installed generation MW
  MAXGEN= fix(PMAX);                         % total PMAX installed gen MW
  MG = MAXGEN;                               % temp store MG to maxgen MW
  if(MG > 90000)                             % however if > 90000, then
    MG = 90000;                              % don't let MG be past 90000
  end                                        % now we sweep from right MG
  JP = fix(CAPA);                            % integer value of CAPA
  P  = CAPA-JP;                              % P is decimal value of CAPA
  ID = fix(DERA);                            % integer value of DERA
  DP = DERA-ID;                              % DP is decimal value of DERA
  for ix=MG:-1:0                             % to left F(ix) down to ix=0
    ix1 = ix +1;                             % ix1 is due to F shifted up 1
    j=fix(ix1-JP);                           % j shifts the down curve CAPA
    Fj=1.-P;                                 % all F(ix<0) = 1
    FP=P;
    if(j >= 1)
      Fj=F(j)*(1.-P);                        % ix is => 0
    end
    if(j-1 >= 1)
      FP=F(j-1)*P;                           % F curve is in two pieces
    end
    jD=fix(ix1-ID);                          % jD points to MW derate state
    FD=1.-DP;                                % all F(jx<0) = 1
    FDP=DP;
    if(jD >= 1)
      FD = F(jD)*(1.-DP);                    % jx is => 0
    end
    if(jD-1 >= 1)
      FDP=F(jD-1)*DP;
    end
    F(ix1)=(1.-FOR-DFOR)*F(ix1) + DFOR*(FD+FDP) + FOR*(Fj+FP);
    if(F(ix1) < 1.E-37)                      % if the LOLP is too small
      F(ix1)=0.;                             % set it to zero, avoid error
    end                                      % now we see if we can shorten
    if((F(ix1) >= 1.E-16) && (MXF < ix))     % up F to save storage space
      MXF=ix;                                % if so we set the new MXF
    end
  end                                        % this ends F right-left sweep
end                                          % this ends read of genr data
fprintf(fout,'\n%12s%11d%3s\n',' MAX GENR  =',MAXGEN,' MW');
fclose(gdata);
DSFU=MAXGEN;                                 % set upper demand boundary
if (DSF > DSFU)
  DSFU=DSF;                                  % set higher upper bound
end
DSFL=0.;                                     % set lower demand to zero
%% now read each hour's demand and variable energy sources
for iter = 1:30                              % begin iterations
 LOLE0 = LOLE1;                              % remember previous iter LOLE
 if(iter == 30)                              % flag we are done iterating
   IP = 1;
 end
 for i = 1:14                                % reset dummy variable to 0
   D(i) = 0.;
 end
 frewind(hdata);                             % return to top of hourly file
 C220 = fgetl(hdata);                        % read hourly title again
 C220 = fgetl(hdata);                        % read YYMMDDHH line & skip it
 if (iter == 1)                              % print headers if iter=1
   D220=strcat('           Year,MoDaHr D,        LOLP,  NETDEM,',C220(14:length(C220(1:NCH))));
   fprintf(foph,'\n%s',D220);                % print new headers in foph
 end
 VRC = 0.;                                   % set variable resource cap=0
 for i=1:NVS                                 % sweep through all the VR's
   VRES(i)=0.;                               % VER energy sum sig days NSH
   VRC=VRC+SF(i)*PCTC(i)/100.;               % sum MW capacity of each VER
 end
 if (iter == 1)
   fprintf(fout,'%12s%11d%3s\n',' VARBL RES =',round(VRC),' MW');
   fprintf(fout,'%12s%11d%3s\n',' GENR+VRES =',MAXGEN+round(VRC),' MW');
   fprintf(fout,'%12s%11d%12s\n',' MAX COPT  =',MXF,' (90000 MAX)');
 end
 C220=fgetl(hdata);                          % read first line hourly data
 D220=C220;                                  % save the C220 into D220
 IFY = sscanf(C220(1:4),'%d');               % first year in hdata
 IYR = IFY-1;                                % do all the years in hdata
 NTH = 0;                                    % number of total hours
 for IY=1:9999                               % for up to 9999 years max
   IYR = IYR+1;
   NSH = 0;                                  % number of significant hours
   LOLE1=0.;                                 % set the AM LOLE to 0
   LOLE2=0.;                                 % set the PM LOLE to 0
   LOLEV=0.;                                 % set the AM + PM LOLE to 0
   LOLH =0.;                                 % set the LOLH to 0
   EUE  =0.;                                 % set the EUE to 0
   ENGT =0.;                                 % set annual total energy to 0
   VRE  =0.;                                 % set VER annual energy to 0
   VREC =0.;                                 % set VR energy curtailed to 0
   IHRS =0 ;                                 % keep track of 1-24 hours/day
   IH2OLD=0;                                 % store previous IHRS to compr
   PLOLP1=0.;                                % set AM peak LOLP to 0
   PLOLP2=0.;                                % set PM peak LOLP to 0
   PKDEM=0.;                                 % set annual peak demand to 0
   PKNET=0.;                                 % set annul net pk demand to 0
   IH3 = 0;                                  % the hour during the day
   IOK = 0;                                  % if IOK=1 print day to foph
   for IH=1:9999                             % for up to 9999 hours per yr
     NTH=NTH+1;                              % total number of hours
     NH=IH;                                  % temp store hours in NH
     [VR] = strread(C220(14:NCH),'%f','delimiter',','); % read hourly per unit data
     DEMD = VR(1);
     HD=DEMD*DSF;                            % hourly demand in MW
     I=fix(HD);                              % set HD to an integer value
     if(HD-I <= .001)                        % this is for HD slightly > I
       HD=I;                                 % round HD down to the integer
     end                                     % needed to get 1986 exact ans
     IH3=IH3+1;
     MW(23,IH3) = sscanf(C220(1:10) ,'%d');  % YYYYMMDDHH in MW(23
     MW(24,IH3) = sscanf(C220(12:12),'%d');  % D (day of week) in MW(24
     MW(21,IH3) = round(HD);                 % the MW demand for hour IH3
     if(HD > PKDEM)                          % if dem is greater than PKDEM
       PKDEM=HD;                             % then update the PKDEM value
     end
     HD1=HD;                                 % temp store HD in HD1
     ENGT=ENGT+HD;                           % sum up the annual energy
     if(NVS > 0)                             % if there are variable resour
       for i=1:NVS                           % sweep through all var resour
         HD=HD-VR(i+1)*SF(i);                % subtract the var res from ld
         MW(i,IH3)=round(VR(i+1)*SF(i));     % capture hourly VR MW values
       end
     end
     MW(22,IH3)=round(HD);                   % net peak demand rounded
     if(HD < 0.)                             % if the load is negative
       VREC=VREC-HD;                         % capture the neg load in VREC
       HD=0.;                                % set the demand to 0
     end
     if(HD > PKNET)                          % see if hourly dem > PKnet ld
       PKNET=HD;                             % if so remember pk hr net dem
     end
     VRE=VRE+(HD1-HD);                       % the var engy is difference
     LOLP=0.;                                % set the LOLP to 0
     for L=1:7                               % begin 7 load levels loop
       HD2=HD+HD1*LFU2(L);                   % dummy HD2 is HD plus deviatn
       if(HD2 < 0.)                          % if the HD2 < 0 set it to 0
         HD2=0.;
       end
       IHD=fix(HD2);                         % convert IH2 to an integer
       P=HD2-IHD;                            % P is the decimal value > IHD
       if((MAXGEN-IHD) <= MXF)               % see if IHD within range MXF
         D(15)=0.;                           % D(15) integrates F for enrgy
         for i=MXF:-1:MAXGEN-IHD             % sweep F from right to left
           FI=1.;                            % assume i is to the far left
           if(i >= 0)                        % but if i is in the OK range
             FI=F(i+1);                      % then get the correct LOLP
           end
           D(15)=D(15)+FI;                   % D(15) is running sum of EUE
         end
         if(P > 0.)                          % if P has remainder then
           IHD=IHD+1;                        % add 1 more MW to the load
           FI=1.;                            % assume we are too far left
           if((MAXGEN-IHD) >= 0)             % if IHD is in the range
             FI=F(MAXGEN-IHD+1);             % then we can get correct LOLP
           end
           D(15)=D(15)+P*FI;                 % add on fraction of MW P*LOLP
         end
         EUE=EUE+D(15)*LFU1(L);              % the EUE is D(15) times LFU1
         FI=1.;                              % assume far to left of F
         if((MAXGEN-IHD) >= 0)               % however if not then
           FI=F(MAXGEN-IHD+1);               % look up the LOLP at IHD+1
         end
         LOLP=LOLP+FI*LFU1(L);               % sum up the LOLPs for 7 steps
       end
     end                                     % end of loop for 7 steps
     if(LOLP >= SLOLP)
       NSH=NSH+1;                            % significant LOLP => SLOLP
       IOK=1;                                % a signifcant LOLP day
       for i=1:NVS
         VRES(i)=VRES(i)+VR(i+1)*SF(i);      % MW VER sum significant hours
       end
     end
     LOLP24(IH3)=LOLP;                       % capture the LOLP this hour
     if(IOK==1 && (IH3==24 || strcmp(C220(9:10),'24')))
       for i=1:24
         if(IP == 1)
           F1=num2str(MW(23,i));             % YYYYMMDDHH put into F1
           fprintf(foph,'\n%4s%2s%6s%4d',F1(1:4),', ',F1(5:10),MW(24,i));
           fprintf(foph,'%s%8.6f%s',',',LOLP24(i),',');
           fprintf(foph,'%9d%s%9d%s',MW(22,i),',',MW(21,i),',');
           for j=1:NVS
             fprintf(foph,'%9d%s',MW(j,i),',');
           end
         end
       end
     end
     if(IH3==24 || strcmp(C220(9:10),'24'))
       IOK=0;                                % set no print for a new day
       IH3=0;                                % begin counter for a new day
     end
     LOLH=LOLH+LOLP;                         % sum the loss of load hours
     IHRS=IHRS+1;                            % find the hour of the day
     if(IHRS <= 12)                          % see if its in the AM
       if(LOLP > PLOLP1)                     % see if we have the max LOLP
         PLOLP1=LOLP;                        % if not capture it
         IH1=IHRS;                           % temporarily remember the max
       end                                   % hour in IH1
     end
     if(IHRS > 12)
       if(LOLP > PLOLP2)                     % if in the PM do same test
         PLOLP2=LOLP;                        % remember the peak PM LOLP
         IH2=IHRS;                           % remember the hour it occured
       end
     end
     if(IHRS == 24)                          % see if we are at end of day
% see if the AM and PM peak LOLPs are separated by at least 6 hours
       if(((IH2-IH1) <= 6) || ((24-IH2OLD+IH1) <= 6))
         if(PLOLP2 >= PLOLP1)                % if not set the smaller to 0
           PLOLP1=0.;                        % here the AM LOLP set to 0
         end
         if(PLOLP1 >= PLOLP2)                % if not set the smaller to 0
           IH2=15;                           % remember if near end of day
           PLOLP2=0.;                        % here the PM LOLP set to 0
         end
       end
       LOLEV=LOLEV+PLOLP1+PLOLP2;            % the LOLEV is sum of AM&PM
       if(PLOLP2 >= PLOLP1)                  % see if PM LOLP is dominant
         PLOLP1=0.;                          % if so set AM LOLP to 0
       end
       if(PLOLP1 >= PLOLP2)                  % see if AM LOLP is dominant
         PLOLP2=0.;
       end
       LOLE1=LOLE1+PLOLP1;                   % sum up the AM LOLPs (LOLEAM)
       LOLE2=LOLE2+PLOLP2;                   % sum up the PM LOLPs (LOLEPM)
       PLOLP1=0.;                            % set LOLPAM to 0 for new day
       PLOLP2=0.;                            % set LOLPPM to 0 for new day
       IHRS=0;                               % set hours in the day to 0
       IH2OLD=IH2;                           % remember previous PM pk hr
     end
     C220 = fgetl(hdata);                    % read a new line of hdata
     C2=C220(1:4);                           % capture the first four char
     D2=D220(1:4);                           % read the previous lines 4 ch
     if(strcmp(C2,D2) == 0)                  % if there is a yr change exit
       break;                                % 0=different 1=same
     end
     D220=C220;                              % see if there is a year chang
   end                                       % the year chg exits this loop
   NY = IY;
   if(IP == 1)
     fprintf(fout,'\n%5d%9s\n',IYR,' RESULTS:');
     fprintf(fout,'%12s%11d%6s\n',' PERIOD    =',NH,' HOURS');
     fprintf(fout,'%12s%11.3f%3s\n',' PEAK DEMD =',PKDEM,' MW');
     RM = (1000.*(RMGEN+VRC))/PKDEM-1000.0;
     RM = RM/10.;
     fprintf(fout,'%12s%11.1f%2s\n',' RESERVE   =',RM,' %');
     fprintf(fout,'%12s%11.0f%4s\n',' LOAD ENGY =',ENGT/1000.,' GWh');
     fprintf(fout,'%12s%11.3f%2s\n',' LOAD FACT =',100.*ENGT/(NH*PKDEM),' %');
     fprintf(fout,'%12s%11.3f%13s\n',' PEAK NETD =',PKNET,' MW (DEMD-VR)');
     fprintf(fout,'%12s%11.0f%4s\n',' VR E USED =',VRE/1000.,' GWh');
     fprintf(fout,'%12s%11.0f%4s\n',' VR E LOST =',VREC/1000.,' GWh');
     fprintf(fout,'%14s%6.2f%6s\n',' Indices for a',PLFU,'% LFU:');
     fprintf(fout,'%12s%11.6f%4s\n',' LOLE(AM)  =',LOLE1,' d/y');
     fprintf(fout,'%12s%11.6f%4s\n',' LOLE(PM)  =',LOLE2,' d/y');
     fprintf(fout,'%12s%11.6f%4s\n',' LOLE      =',LOLE1+LOLE2,' d/y');
     fprintf(fout,'%12s%11.6f%9s\n',' LOLEV **  =',LOLEV,' events/y');
     fprintf(fout,'%12s%11.0f%3s\n',' LOLEMW    =',EUE/LOLH,' MW');
     fprintf(fout,'%12s%11.6f%4s\n',' LOLH      =',LOLH,' h/y');
     fprintf(fout,'%12s%11.6f%8s\n',' LOLH/event=',LOLH/LOLEV,' h/event');
     fprintf(fout,'%12s%11.0f%4s\n',' EUE MWh   =',EUE,' MWh');
     fprintf(fout,'%12s%11.2f%7s\n',' EUE ppm   =',EUE/ENGT*1.E6,' pu ppm');
     fprintf(fout,'%12s%11.6f%2s\n',' EUE %     =',EUE/ENGT*100.,' %');
     fprintf(fout,'%6s%5.0e%1s%11d%4s\n',' LOLP>',SLOLP,'=',NSH,' hrs');
   end
   D(1) = D(1)+PKDEM;                        % total of all peak demands
   D(2) = D(2)+ENGT/1000.;                   % total of all energy demand
   D(3) = D(3)+100.*ENGT/(NH*PKDEM);         % total demand load factor
   D(4) = D(4)+PKNET;                        % total net peak of all years
   D(5) = D(5)+VRE/1000.;                    % total of variable enrgy sour
   D(6) = D(6)+VREC/1000.;                   % total dumped variable engy
   D(7) = D(7)+LOLE1;                        % total am loss of load event
   D(8) = D(8)+LOLE2;                        % total pm loss of load event
   D(9) = D(9)+LOLEV;                        % total loss of load events
   D(10) = D(10)+LOLH;                       % sum of all loss of load hrs
   D(11) = D(11)+EUE;                        % sum of all unserved energy
   D(12) = D(12)+ENGT;                       % total energy of all demand
   D(13)=D(13)+NSH;                          % numb significant period hrs
   D(14)=D(14)+RM;                           % reserve margin calculation
   C2=C220(1:3);                             % read first three char again
   if(strcmp(C2,'end') == 1)                 % see if we are at end of file
     break;                                  % if so break out of this loop
   end
   D220=C220;                                % remember previous line read
 end
 LOLE1=(D(7)+D(8))/NY;
 if(LOLE1 > TLOLE && DSF < DSFU)
   DSFU=DSF;                                 % reduce upper demand limit
 end
 if(LOLE1 < TLOLE && DSF > DSFL)
   DSFL=DSF;                                 % increase lower demand limit
 end
 if(NY > 1 && IP == 1)                       % print averages for > 1 year
   fprintf(fout,'\n%16s\n',' AVERAGE VALUES:');
   fprintf(fout,'%12s%11d%6s  \n',' PERIOD    =',fix(NTH/NY),' HOURS');
   fprintf(fout,'%12s%11.3f%3s\n',' PEAK DEMD =',D(1)/NY,' MW');
   fprintf(fout,'%12s%11.1f%2s\n',' RESERVE   =',D(14)/NY,' %');
   fprintf(fout,'%12s%11.0f%4s\n',' LOAD ENGY =',D(2)/NY,' GWh');
   fprintf(fout,'%12s%11.3f%2s\n',' LOAD FACT =',D(3)/NY,' %');
   fprintf(fout,'%12s%11.3f%13s\n',' PEAK NETD =',D(4)/NY,' MW (DEMD-VR)');
   fprintf(fout,'%12s%11.0f%4s\n',' VR E USED =',D(5)/NY,' GWh');
   fprintf(fout,'%12s%11.0f%4s\n',' VR E LOST =',D(6)/NY,' GWh');
   fprintf(fout,'%14s%6.2f%6s\n',' Indices for a',PLFU,'% LFU:');
   fprintf(fout,'%12s%11.6f%4s\n',' LOLE(AM)  =',D(7)/NY,' d/y');
   fprintf(fout,'%12s%11.6f%4s\n',' LOLE(PM)  =',D(8)/NY,' d/y');
   fprintf(fout,'%12s%11.6f%4s\n',' LOLE      =',LOLE1,' d/y');
   fprintf(fout,'%12s%11.6f%9s\n',' LOLEV **  =',D(9)/NY,' events/y');
   fprintf(fout,'%12s%11.0f%3s\n',' LOLEMW    =',D(11)/D(10),' MW');
   fprintf(fout,'%12s%11.6f%4s\n',' LOLH      =',D(10)/NY,' h/y');
   fprintf(fout,'%12s%11.6f%8s\n',' LOLH/event=',D(10)/D(9),' h/event');
   fprintf(fout,'%12s%11.0f%4s\n',' EUE MWh   =',D(11)/NY,' MWh');
   fprintf(fout,'%12s%11.2f%7s\n',' EUE ppm   =',D(11)/D(12)*1.E6,' pu ppm');
   fprintf(fout,'%12s%11.6f%2s\n',' EUE %     =',D(11)/D(12)*100.,' %');
   fprintf(fout,'%6s%5.0e%1s%11d%s\n',' LOLP>',SLOLP,'=',round(D(13)/NY),' avg hrs');
 end                                         % end of IY
% begin adjusting the demand trying to get to  the desired Target LOLE
  if((JS == 0) && (TLOLE > 0.))
    fprintf(1,'\n%s',' LOLE d/y    MW Demand     Upper MW     Lower MW');
%                      --------    ---------    ---------    ---------
    JS=1;
  end
  if((IP == 1) && (NVS > 0) && (D(13) > 0.))
    fprintf(fout,'\n%s',' Variable Resource Capacity Credits');
    fprintf(fout,'\n%s%5.0e%s\n',' Max Net Demand hrs for LOLP>',SLOLP,':');
    fprintf(fout,'\n');
    for i=1:NVS
      fprintf(fout,'%6.1f%s',100.*VRES(i)/D(13)/SF(i),'%');
    end
    fprintf(fout,'\n');
  end
  if(TLOLE > 0.)
    fprintf(1,'\n%9.6f%13.7g%13.7g%13.7g',LOLE1,DSF,DSFU,DSFL);
  end
  if(IP == 1)
    break;                                   % skip iterative target LOLE or we are ready to wrap it up
  end
  if((abs(TLOLE-LOLE1) <= .0001*TLOLE) || (DSFU-DSFL < .01))
    if(LOLE1 >= TLOLE)
      IP=1;
      continue;
    end
  end
  if((TLOLE > LOLE1) && (DSF > DSFL))
    DSFL=DSF;                                % lower the upper bound to DSF
  end
  if((TLOLE < LOLE1) && (DSF < DSFU))
    DSFU=DSF;                                % raise the lower bound to DSF
  end
  DSF=(DSFU+DSFL)/2.;                        % average of high & low bounds
end                                          % end iter
fprintf(fout,'\n');
fprintf(fout,' %s\n','** LOLE  measures events/24 hrs');
fprintf(fout,' %s\n','   LOLEV measures events/12 hrs');
fprintf(fope,'\n%s','          YEAR,  PKDEMD,     %RESV,LoadGWh,%LDFact,');
fprintf(fope,'%s','PKnetMW,    VRGWh,      VRlost,        %LFU,LOLE(AM),');
fprintf(fope,'%s','LOLE(PM),LOLE(d/y),LOLEV(#/y),LOLEMW,LOLH(h/y),LOLH');
fprintf(fope,'%s%5.0e%s','(h/e),EUEMWh,   EUEppm,    EUE%,LOLP>',SLOLP,' hrs');
fclose(fout);
fop = fopen('OP.txt');                       % read the output report text file
for i=1:11
  C220 = fgetl(fop);                         % skip 10 lines in OP.txt
end
for IY=1:NY+1
  C220 = fgetl(fop);                         % skip a line
  C220 = fgetl(fop);                         % read the year as a string
  fprintf(fope,'\n%4s%s',C220(2:5),',');
  C220 = fgetl(fop);                         % skip hours
  C220 = fgetl(fop);
  D(1) = sscanf(C220(13:23),'%f');           % read the pk demd
  fprintf(fope,'%11.3f%s',D(1),',');
  C220 = fgetl(fop);
  D(2) = sscanf(C220(13:23),'%f');           % read the reserve margin
  fprintf(fope,'%11.1f%s',D(2),',');
  C220 = fgetl(fop);
  D(3) = sscanf(C220(13:23),'%f');           % read the load energy
  fprintf(fope,'%11.0f%s',D(3),',');
  C220 = fgetl(fop);
  D(4) = sscanf(C220(13:23),'%f');           % read the load factor
  fprintf(fope,'%11.3f%s',D(4),',');
  C220 = fgetl(fop);
  D(5) = sscanf(C220(13:23),'%f');           % read the peak net demand
  fprintf(fope,'%11.3f%s',D(5),',');
  C220 = fgetl(fop);
  D(6) = sscanf(C220(13:23),'%f');           % read the VR energy used
  fprintf(fope,'%11.0f%s',D(6),',');
  C220 = fgetl(fop);
  D(7) = sscanf(C220(13:23),'%f');           % read the VR energy lost
  fprintf(fope,'%11.0f%s',D(7),',');
  C220 = fgetl(fop);
  D(8) = sscanf(C220(15:20),'%f');           % read the percent LFU
  fprintf(fope,'%11.2f%s',D(8),',');
  C220 = fgetl(fop);
  D(9) = sscanf(C220(13:23),'%f');           % read the AM LOLE
  fprintf(fope,'%11.6f%s',D(9),',');
  C220 = fgetl(fop);
  D(10)= sscanf(C220(13:23),'%f');           % read the PM LOLE
  fprintf(fope,'%11.6f%s',D(10),',');
  C220 = fgetl(fop);
  D(11)= sscanf(C220(13:23),'%f');           % read the total LOLE
  fprintf(fope,'%11.6f%s',D(11),',');
  C220 = fgetl(fop);
  D(12)= sscanf(C220(13:23),'%f');           % read the LOLEV
  fprintf(fope,'%11.6f%s',D(12),',');
  C220 = fgetl(fop);
  D(13)= sscanf(C220(13:23),'%f');           % read the LOLE MW
  fprintf(fope,'%11.0f%s',D(13),',');
  C220 = fgetl(fop);
  D(14)= sscanf(C220(13:23),'%f');           % read the LOLH
  fprintf(fope,'%11.6f%s',D(14),',');
  C220 = fgetl(fop);
  D(15)= sscanf(C220(13:23),'%f');           % read the LOLH/event
  fprintf(fope,'%11.6f%s',D(15),',');
  C220 = fgetl(fop);
  D(16)= sscanf(C220(13:23),'%f');           % read the EUE MWh
  fprintf(fope,'%11d%s',fix(D(16)),',');
  C220 = fgetl(fop);
  D(17)= sscanf(C220(13:23),'%f');           % read the EUE ppm
  fprintf(fope,'%11.2f%s',D(17),',');
  C220 = fgetl(fop);
  D(18)= sscanf(C220(13:23),'%f');           % read the EUE %
  fprintf(fope,'%11.6f%s',D(18),',');
  C220 = fgetl(fop);
  D(19)= sscanf(C220(13:23),'%f');           % read the LOLP>1e-04
  fprintf(fope,'%11d%s',fix(D(19)+.5),',');
  if(strcmp(F1,'AVER') == 1)
    break;
  end
 if(strcmp(F1,'AVER') == 1  ||  NY == 1)
   break;
 end
end
fprintf(1,'\n%s\n','SEE REPORT FILES OP.TXT OP.CSV & OPH.CSV');
fclose('all');
