Create a directory and copy the files to your directory.
Run the Matlab RTS3.m or Fortran RTS3.for in F77 or F90.
Enter generator file G1979.txt and hit enter twice.

Output reports will be stored in OP.txt OP.csv and OPH.csv.

You can also run the program with a target LOLE.  If the
solution does not reach your target LOLE try increasing
the demand in the G data file and rerunning. This program
should recreate the "exact" indices in the 1986 RTS paper.

You may use the RTS3 program as you wish but the results
you obtain do not have any guarantees from me that your
results are accurate.  It's an experimental tool and
there are likely to be errors in the code.  Use it at
your own risk.

Gene Preston, PhD
http://egpreston.com
g.preston@ieee.org (preferred)
512-892-3621 (leave message)
